/*
  Beautiful Codes are MUCH better than 'Shorter' ones !
user  : triveni
date  : 31/01/2016
time  : 10:33:44
*/
#include <bits/stdc++.h>

using namespace std;

#define      pii               std::pair<int,int>
#define      vi                std::vector<int>
#define      mp(a,b)           make_pair(a,b)
#define      pb(a)             push_back(a)
#define      each(it,s)        for(auto it = s.begin(); it != s.end(); ++it)
#define      rep(i, n)         for(int i = 0; i < (n); ++i)
#define      fill(a)           memset(a, 0, sizeof (a))
#define      sortA(v)          sort(v.begin(), v.end())
#define      sortD(v)          sort(v.begin(), v.end(), greater<auto>())
#define      X                 first
#define      Y                 second

typedef long long ll;
ll MOD = 1000000007;

ll dp[1010][256];

void solve(){
	string s;
	cin >> s;
	int n = s.length();
	ll ans = 1;
	for(int i = 0; i < n; ++i){
		set<char> st;
		for(int j = i-1; j <= i+1; j++){
			if(j >= 0 && j < n) st.insert(s[j]);
		}
		ans = ans * st.size() % MOD;
	}
	cout << ans << "\n";
}

int main()
{
	int T;
	cin >> T;
	for(int tc = 1; tc <= T; ++tc){
		printf("Case #%d: ",tc);
		solve();
	}
	return 0;
}
