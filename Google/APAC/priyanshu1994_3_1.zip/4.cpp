#include <bits/stdc++.h>

using namespace std;

#define sd(x) scanf("%d",&x);
#define LL long long
#define LD long double
#define PB push_back
#define MP make_pair
#define F first
#define S second
#define Fill(a, b) memset(a, b, sizeof(a))
#define INF 1000000000009LL

typedef pair<int,int> PII;
typedef vector<int> VI;

#define M 10010
#define N 1123456

LL arr[N],arr2[N];
int n,q;

LL count(LL sum)
{
	LL ans = 0;
	int temp = 0;
	for(int i=1;i<=n;i++)
	{
		if(arr[i] - arr[temp] <= sum)
			ans += (i-temp);
		else
		{
			temp++;
			i--;
		}
	}
	return ans;
}

LL binary_search(LL start, LL end, LL target)
{
	if(start == end)
		return start;
	LL mid = (start+end)/2;
	if(count(mid)<target)
		return binary_search(mid+1,end,target);
	else
		return binary_search(start,mid,target);
}

LL calc(LL l, LL r)
{
	LL ans = 0;
	LL val = binary_search(1,INF,r);
	LL tmp = count(val-1);
	int j=0;
	for(int i=1;i<=n;i++)
	{
		if(arr[i]-arr[j]<= (val-1))
			ans=ans+arr[i]*(i-j)-(arr2[i-1]-arr2[j-1]);
		else
		{
			j++;
			i--;
		}
	}
	ans += (r-tmp)*val;

	LL diff = 0;
	val = binary_search(1,INF,l-1);
	tmp = count(val-1);
	j=0;
	for(int i=1;i<=n;i++)
	{
		if(arr[i]-arr[j]<= (val-1))
			diff=diff+arr[i]*(i-j)-(arr2[i-1]-arr2[j-1]);
		else
		{
			j++;
			i--;
		}
	}
	diff += (l-1-tmp)*val;
	return ans-diff;
}

void solve()
{
	scanf("%d%d",&n,&q);
	arr[0]=0;
	for(int i=1;i<=n;i++)
		scanf("%lld",&arr[i]);
	for(int i=1;i<=n;i++)
		arr[i]+=arr[i-1];
	arr2[0]=0;
	for(int i=1;i<=n;i++)
		arr2[i]= arr2[i-1]+arr[i];
	LL l,r;
	for(int i=0;i<q;i++)
	{
		scanf("%lld%lld",&l,&r);
		printf("%lld\n",calc(l,r));
	}
}

int main()
{
	//printf("hi\n");
	freopen("input4.txt","r",stdin);
	freopen("output4.txt","w",stdout);
	int t=1;
	scanf("%d",&t);
	for(int i=1;i<=t;i++)
	{
		printf("Case #%d:\n",i);
		solve();
	}
}