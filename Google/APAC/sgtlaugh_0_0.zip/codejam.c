#include <stdio.h>
#include <string.h>
#include <stdbool.h>

#define MAX 105
#define MOD 1000000007
#define clr(ar) memset(ar, 0, sizeof(ar))
#define read() freopen("lol.txt", "r", stdin)
#define write() freopen("out.txt", "w", stdout)

char str[MAX];

int main(){
    read();
    write();
    int T = 0, t, i, j, k;

    scanf("%d", &t);
    while (t--){
        scanf("%s", str);
        int n = strlen(str);
        long long res = 1;

        for (i = 0; i < n; i++){
            int counter = 0;
            for (j = 0; j < 26; j++){
                k = j + 'a';
                if (str[i] == k || ( (i + 1) < n && str[i + 1] == k) || (i > 0 && str[i - 1] == k)){
                    counter++;
                }
            }
            res = (res * counter) % MOD;
        }

        printf("Case #%d: %lld\n", ++T, res);
    }
    return 0;
}
