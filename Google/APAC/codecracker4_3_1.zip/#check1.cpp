//Author : Jatin Goyal
//codecracker4

#include<bits/stdc++.h>
using namespace std;
#define MOD 1000000007  //NA
#define N 211111
#define ll long long int
#define dt ll
#define all(c) c.begin(), c.end()
#define dcl(a) memset(a,0,sizeof(a))
#define rep(i,a,b) for(dt i=a;i<=(dt)(b);i++)
#define tr(container, it) for(vector<dt> ::iterator it= container.begin(); it!=container.end(); it++)
#define trp(container, it) for(vector<pair<dt,dt> >::iterator it = container.begin(); it!=container.end(); it++)
#define tra(container, it) for(typeof(container.begin()) it = container.begin(); it!=container.end(); it++)
#define cc1(a)cout<<#a<<": "<<a<<endl;
#define cc2(a,b)cout<<#a<<": "<<a<<" , "<<#b<<": "<<b<< endl;
#define cc3(a,b,c)cout<<#a<<": "<<a<<" , "<<#b<<": "<<b<<" , "<<#c<<": "<<c<<endl;
#define cc4(a,b,c,d)cout<<#a<<": "<<a<<" , "<<#b<<": "<<b<<" , "<<#c<<": "<<c<<" , "<<#d<<": "<<d<<endl;
#define pr pair<dt,dt>  //NA
#define mp(a,b) make_pair(a,b)
#define pb push_back  //NA
#define gc getchar  //NA
#define F first
#define S second
vector<ll>vec;
ll a[N];
ll subsum[N];
ll values(ll l)
{
    ll ok=0;
    rep(i,1,vec.size()-1)
    {
        ok+=i-(lower_bound(all(vec),vec[i]-l)-vec.begin());
    }
    return ok;
}
ll sums(ll l)
{
    ll ok=0;
    if(l<=0) return 0;
    rep(i,1,vec.size()-1)
    {
        ll lt=lower_bound(all(vec),vec[i]-l)-vec.begin();
        ll rt=i;
        ok+=subsum[rt]-subsum[lt]-(vec[rt]-vec[lt])*lt;

    }
    return ok;
}
int main()
{
	freopen("D-large.in","r",stdin);
    freopen("##out.cpp","w",stdout);
	ios_base::sync_with_stdio(0);
	ll t;
	cin>>t;
	rep(tes,1,t)
	{
	    ll n,q;
	    cout<<"Case #"<<tes<<":"<<endl;
	    cin>>n>>q;
	    rep(i,0,n-1) cin>>a[i];
	    vec.pb(0);
	    rep(i,0,n-1)
	    {
	        vec.pb(a[i]+vec.back());
	    }

	    subsum[0]=0;
	    rep(i,1,n)
	    {
	        subsum[i]=subsum[i-1]+((ll)i*(ll)a[i-1]);
	    }
	    rep(i,1,n)
	    {
	       // subsum[i]+=subsum[i-1];
	    }
	    rep(i,0,n)
	    {
	        //cc2(i,subsum[i])
	    }
	    while(q--)
        {
            ll x,y,left,right;
            cin>>x>>y;
            x--;
            ll l=0,r=100ll*n;
            while(l<=r)
            {
                ll mid=(l+r)/2;
                if(values(mid)>=x)
                {
                    left=mid;
                    r=mid-1;
                }
                else
                {
                    l=mid+1;
                }
            }
            l=1,r=100*n;
            while(l<=r)
            {
                ll mid=(l+r)/2;
                if(values(mid)>=y)
                {
                    right=mid;
                    r=mid-1;
                }
                else
                {
                    l=mid+1;
                }
            }

           // cc4(left,right,x,y)
            ll lyes=sums(left-1)+(x-values(left-1))*left;
            ll ryes=sums(right-1)+(y-values(right-1))*right;
            cout<<ryes-lyes<<endl;
        }
	    rep(i,0,10)
	    {
	       // cc3(i,values(i),sums(i));
	    }
	    vec.clear();
	}
}
