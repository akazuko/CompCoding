#include<bits/stdc++.h>

using namespace std;

#define sd(x) scanf("%d",&x);
#define slld(x) scanf("%lld",&x);
#define LL long long
#define LD long double
#define PB push_back
#define MP make_pair
#define F first
#define S second
#define Fill(a, b) memset(a, b, sizeof(a))
#define INF 2000000009

typedef pair<int,int> PII;
typedef vector<int> VI;

int arr[212345];
long long cum[212345];
long long cumcum[212345];
#define maxr 200000000

long long poss(long long rnk , long long elem,int n)
{
    int l=1,r=1;
    long long totlss = 0;
    for(int i=1;i<=n;i++)
    {
        l = i;
        while(r<n)
        {
            if((cum[r+1] - cum[l-1]) < elem)
            {
                r++;
            }
            else break;
        }
        if((cum[r] - cum[l-1]) >= elem)r--;
        totlss += (r-l+1);
    }
    if(totlss < rnk)
    {
        return totlss;
    }
    else return -1;
}

long long poss2(long long rnk , long long elem,int n)
{
    int l=1,r=1;
    long long totlss = 0;
    for(int i=1;i<=n;i++)
    {
        l = i;
        while(r<n)
        {
            if((cum[r+1] - cum[l-1]) <= elem)
            {
                r++;
            }
            else break;
        }
        if((cum[r] - cum[l-1]) > elem)r--;
        totlss += (r-l+1);
    }
    if(totlss >= rnk)
    {
        return totlss;
    }
    else return -1;
}

vector<long long> v;
long long retsum(long long l,long long r , int n)
{
    long long lo,hi;
    long long res = 0;
    //cout<<l<<" !!! "<<r<<endl;
    for(int i=1;i<=n;i++)
    {
        lo = v[i-1] + (l-1);
        std::vector<long long>::iterator low,up;
        low=std::upper_bound (v.begin(), v.end(), lo); //
        hi = v[i-1] + r;
        up= std::upper_bound (v.begin(), v.end(), hi); //
        int x,y;
        x = (low- v.begin());
        y = (up- v.begin())-1;
        //cout<<lo<<" "<<hi<<endl;
        //cout<<i<<" "<<x<<" "<<y<<" "<<cumcum[y]<<" "<<cumcum[x-1]<<" "<<cum[i]<<endl;
        if(y > n)y--;
        if(y < x)continue;
        res += (cumcum[y] - cumcum[x-1] - cum[i-1]*(y-x+1));
        //cout<<i<<" "<<x<<" "<<y<<" "<<cumcum[y]<<" "<<cumcum[x-1]<<" "<<cum[i]<<endl;
    }
    return res;
}
void solve()
{
    int n,q;
    sd(n);
    sd(q);
    memset(arr,0,sizeof(arr));
    memset(cum,0,sizeof(arr));
    memset(cumcum,0,sizeof(arr));
    v.clear();
    v.PB(0);

    for(int i=1;i<=n;i++)
    {
        sd(arr[i]);
        cum[i] = cum[i-1] + arr[i];
        cumcum[i] = cum[i] + cumcum[i-1];
        v.PB(cum[i]);
    }
    v.PB(100000000000000LL);
    while(q--)
    {
        long long l,r;
        cin>>l>>r;
        long long f1l=0 , f1r = maxr , f1poss = -1,mid,lss;
        while(f1l <= f1r)
        {
            mid = (f1l + f1r)/2;
            if(f1l == f1r)
            {
                if(poss(l,mid,n) != -1)
                {
                    f1poss = mid;
                    lss = poss(l,mid,n);
                }
                break;
            }
            if(poss(l,mid,n) != -1)
            {
                f1poss = mid;
                lss = poss(l,mid,n);
                f1l = mid+1;
            }
            else
            {
                f1r = mid-1;
            }
        }

        f1l=0 , f1r = maxr;
        long long f2poss = -1,grt;
        while(f1l <= f1r)
        {
            mid = (f1l + f1r)/2;
            if(f1l == f1r)
            {
                if(poss2(r,mid,n) != -1)
                {
                    f2poss = mid;
                    grt = poss2(r,mid,n);
                }
                break;
            }
            if(poss2(r,mid,n) != -1)
            {
                f2poss = mid;
                grt = poss2(r,mid,n);
                f1r = mid-1;
            }
            else
            {
                f1l = mid+1;
            }
        }

        //cout<<f1poss<<" "<<f2poss<<" "<<lss<<" "<<grt<<endl;
        long long finres = 0;
        finres -= (l-1 - lss)*f1poss;
        finres -= (grt-r)*f2poss;
        finres += retsum(f1poss,f2poss,n);
        cout<<finres<<endl;

    }



}
int main()
{
    freopen("ap4.in","r",stdin);
    freopen("apout4.txt","w",stdout);
    int t;
    sd(t);
    for(int test=1;test<=t;test++)
    {
        printf("Case #%d:\n",test);
        solve();
    }
}
