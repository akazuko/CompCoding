#include<bits/stdc++.h>
using namespace std;

// Numeric Constants
#define N 1000000007
#define maxs 200005
#define mins 1005
#define eps 0.000000000001
#define imax 2000000200
#define llmax 1000000002000000000ll
#define pi 3.141592653589793

// Others
#define ll long long
#define pb push_back
#define gc getchar_unlocked
#define iosbase ios_base::sync_with_stdio(false)
#define pii pair<int,int>
#define pll pair<ll,ll>
#define ppi pair<pair<int,int>,int>
#define ppl pair<pll,ll>
#define vi vector<int>
#define sc scanf
#define pr printf
#define lld I64d
#define F first
#define S second
#define siter set<int>::iterator
#define p_pq priority_queue
#define ub upper_bound
#define lb lower_bound

double dp[2][32][100005];

int main()
{
	int t,n,k,a,b,c,x,i,j,T,l;
	sc("%d",&t);
	T=t;
	while(t--){
		sc("%d %d %d %d %d %d",&n,&x,&k,&a,&b,&c);
		for(i=0;i<2;i++){
			for(j=0;j<=30;j++){
				for(l=0;l<=n;l++){
					dp[i][j][l]=0;
				}
			}
		}
		for(i=0;i<=30;i++){
			if((1<<i)&x){
				dp[1][i][0]=1.0;
				dp[0][i][0]=0.0;
			}
			else{
				dp[1][i][0]=0.0;
				dp[0][i][0]=1.0;
			}
		}
		double ans=0.0;
		for(i=0;i<=30;i++){
			int bit;
			if((1<<i)&k){
				bit=1;
			}
			else{
				bit=0;
			}
		//	cout<<bit<<endl;
			for(j=0;j<n;j++){
				dp[(0^bit)][i][j+1]+=(double)(dp[0][i][j]*c)/100.0;
				dp[(1^bit)][i][j+1]+=(double)(dp[1][i][j]*c)/100.0;
				dp[(0 | bit)][i][j+1]+=(double)(dp[0][i][j]*b)/100.0;
				dp[(1 | bit)][i][j+1]+=(double)(dp[1][i][j]*b)/100.0;
				dp[(0 & bit)][i][j+1]+=(double)(dp[0][i][j]*a)/100.0;
				dp[(1 & bit)][i][j+1]+=(double)(dp[1][i][j]*a)/100.0;
			}
			ans=ans+(1<<i)*dp[1][i][n];
		}
		pr("Case #%d: %.12lf\n",T-t,ans);
	}
	return 0;
}