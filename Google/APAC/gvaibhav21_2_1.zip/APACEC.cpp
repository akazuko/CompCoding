#include<bits/stdc++.h>
using namespace std;
 
#define sd(mark) scanf("%d",&mark)
#define ss(mark) scanf("%s",&mark)
#define sl(mark) scanf("%lld",&mark)
#define debug(mark) printf("check%d\n",mark)
#define clr(mark) memset(mark,0,sizeof(mark))
#define F first
#define S second
#define MP make_pair
#define PB push_back
#define ll long long
#define ld long double

int main()
{
	freopen("in1.txt","r",stdin);
	freopen("out1.txt","w",stdout);

	int t,tt,i,j,n,x,k;
	ld a,b,c;
	sd(t);
	for(tt=1;tt<=t;++tt)
	{
		sd(n);sd(x);sd(k);
		scanf("%Lf %Lf %Lf",&a,&b,&c);
		a/=100;b/=100;c/=100;
		ld ans=0;
		for(i=0;i<30;++i)
		{
			ld p,p1;
			if(x&(1<<i))
				p=1;
			else
				p=0;
			for(j=0;j<n;++j)
			{
				p1=0;
				if(k&(1<<i))
					p1=p1+a*p;

				if(k&(1<<i))
					p1=p1+b;
				else
					p1=p1+b*p;

				if(k&(1<<i))
					p1=p1+c*(1-p);
				else
					p1=p1+c*p;

				p=p1;
			}
			ans=ans+p*(1<<i);
		}
		printf("Case #%d: %.12Lf\n",tt,ans);
	}
}