#include<bits/stdc++.h>

#define lli long long int
#define llu unsigned long long int
#define ld long double
#define all(v) v.begin(),v.end()
#define pb push_back
#define mp make_pair
#define F first
#define S second
#define si(n) scanf("%d",&n)
#define slli(n) scanf("%lld",&n);
#define ss(n) scanf("%s",n);

const long double EPS = 1e-10;
const lli MOD = 1000000007ll;
const lli mod1 = 1000000009ll;
const lli mod2 = 1100000009ll;
int INF = 2147483645;
lli INFINF = 9223372036854775807;
int debug = 0;

using namespace std;

void print(int a[],int s,int e){for(int i=s;i<=e;i++)cout<<a[i]<<" ";cout<<"\n";}
void print(vector<int> &v,int s,int e){for(int i=s;i<=e;i++)cout<<v[i]<<" ";cout<<"\n";}
void print(vector<int> &v){for(int x:v)cout<<x<<" ";cout<<"\n";}

lli bit_count(lli _x){lli _ret=0;while(_x){if(_x%2==1)_ret++;_x/=2;}return _ret;}
lli bit(lli _mask,lli _i){return (_mask&(1<<_i))==0?0:1;}
lli powermod(lli _a,lli _b,lli _m){lli _r=1;while(_b){if(_b%2==1)_r=(_r*_a)%_m;_b/=2;_a=(_a*_a)%_m;}return _r;}
lli add(lli a,lli b,lli m=MOD){lli x=a+b;while(x>=m)x-=m;return x;}
lli sub(lli a,lli b,lli m=MOD){lli x=a-b;while(x<0)x+=m;return x;}
lli mul(lli a,lli b,lli m=MOD){lli x=a*b;x%=m;return x;}

lli T;
lli M,N;
lli K[15],L[15];
lli A[15][15]; // power
lli C[15][15]; // cost[i][j], j to j+1
vector<pair<lli,lli> > v[12];
lli ans;

void solve1(lli spent,lli power,lli n,lli used){
    if(n==N/2+1){
        if(spent>M)return;
        v[used].pb({spent,power});
        return;
    }
    lli prev = 0;
    solve1(spent,power,n+1,used);
    solve1(spent,power+A[n][L[n]],n+1,used+1);
    for(int i=L[n]+1;i<=K[n];i++){
        solve1(spent+C[n][i-1]+prev,power+A[n][i],n+1,used+1);
        prev += C[n][i-1];
    }
}

void solve2(lli spent,lli power,lli n,lli used){
    if(n==N+1){
        if(spent > M)
            return;
        lli rem = M - spent;
        lli more = 8 - used;
        int low = 0,high = v[more].size()-1,idx = -1,mid;
        while(low<=high){
            mid = (low + high)>>1;
            if(v[more][mid].F <= rem)
                idx = mid;
            if(v[more][mid].F <= rem)
                low = mid + 1;
            else
                high = mid - 1;
        }
        lli add;
        if(idx!=-1)
            add = power+v[more][idx].S;
        else
            add = 0;

        ans = max(ans,add);
        return;
    }
    lli prev = 0;
    solve2(spent,power,n+1,used);
    solve2(spent,power+A[n][L[n]],n+1,used+1);
    for(int i=L[n]+1;i<=K[n];i++){
        solve2(spent+C[n][i-1]+prev,power+A[n][i],n+1,used+1);
        prev += C[n][i-1];
    }
}

int main()
{
#ifndef ONLINE_JUDGE
    freopen("input.txt","r",stdin);
    freopen("output.txt","w",stdout);
    debug = 1;
#endif
    srand (time(NULL));

    slli(T);
    for(int t=1;t<=T;t++){
        for(int i=1;i<=7;i++)
            v[i].clear();
        slli(M);slli(N);
        for(int i=1;i<=N;i++){
            slli(K[i]);
            slli(L[i]);
            for(int j=1;j<=K[i];j++)
                slli(A[i][j]);
            for(int j=1;j<=K[i]-1;j++)
                slli(C[i][j]);
        }
        solve1(0,0,1,0);
        ans = -1;
        for(int i=1;i<=7;i++)
            sort(all(v[i]));
        for(int j=1;j<=7;j++)
            for(int i=1;i<v[j].size();i++){
                    v[j][i].S = max(v[j][i].S,v[j][i-1].S);
            }
        solve2(0,0,N/2+1,0);
        cout<<"Case #"<<t<<": "<<ans<<"\n";
    }

    return 0;
}
